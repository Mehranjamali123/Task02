import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

sns.set_theme(style="darkgrid")

# Load Dataset

df = pd.read_excel('Dataset for Data Analytics.xlsx')

print("shape:", df.shape)

print("\nprint five rows: ", df.head())

print("\ncolumn name : ", df.columns.to_list())

print("\nData types: ", df.dtypes)

print("\nMissing values: ", df.isnull().sum())


# Data Cleaning

# convert date column to proper datetime format

df["Date"] = pd.to_datetime(df["Date"]) 

# Extract usefull time features
df["Month"] = df["Date"].dt.month
df["Day"] = df["Date"].dt.day
df["Year"] = df["Date"].dt.year
df["Quarter"] = df["Date"].dt.quarter
df["DayOfWeek"] = df["Date"].dt.day_name()
df["MonthName"] = df["Date"].dt.strftime("%b")

df["CouponCode"] = df["CouponCode"].fillna("No Coupon")

print("missing after cleaning: ", df.isnull().sum().sum())
print(df[["Month","Day","Year","DayOfWeek","TotalPrice","CouponCode"]].head())

num_col = ["Quantity","UnitPrice","TotalPrice","ItemsInCart"]

print(df[num_col].describe().round(2))

for col in num_col:
    print(f"\n{col}")

    print(f" Count = {df[col].count()}")
    print(f" Mean = {df[col].mean():.2f}")
    print(f" Median = {df[col].median():.2f}")
    print(f" Std = {df[col].std():.2f}")

print("\nRevenue by product:")
print(df.groupby("Product")["TotalPrice"].sum()
      .sort_values(ascending=False).round(2))

print("\nOrder status counts: ")
print(df["OrderStatus"].value_counts())

def find_outliers(col):
    Q1 = df[col].quantile(0.25)
    Q3  =df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5*IQR 
    upper = Q3 +1.5*IQR
    out = df[(df[col] < lower) | (df[col] > upper)]
    print(f"{col}: {len(out)} outliers | fence [{lower:.1f}, {upper:.1f}]")

for col in ["Quantity","UnitPrice", "TotalPrice","ItemsInCart"]:
    find_outliers(col)

z = np.abs(stats.zscore(df["TotalPrice"]))

print(f"\nZ-Score outliers (|z|>3):{(z>3).sum()} rows")

print("\nRevenue by Referral Source:")
print(df.groupby("ReferralSource")["TotalPrice"].sum().sort_values(ascending=False).round(2))

print("\nRevenue by Payment Method:")
print(df.groupby("PaymentMethod")["TotalPrice"].sum().sort_values(ascending=False).round(2))

print("\nCoupon Usage:")
print(df["CouponCode"].value_counts())

corr = df[['Quantity','UnitPrice','TotalPrice','ItemsInCart']].corr()
print(corr.round(3))


plt.figure(figsize=(8,6))
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm",square=True )
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("chart5_correlation_heatmap.png")
plt.show()


# chart 1 Revenue by product

prod_rev = df.groupby("Product")["TotalPrice"].sum().sort_values()


plt.figure(figsize=(10,5))
prod_rev.plot(kind="barh", color = "steelblue", edgecolor = "white")
plt.title("Total Revenue by Product")
plt.xlabel("Total Revenue ($)")
plt.tight_layout()
plt.savefig("chart1_revenue_by_product.png")
plt.show()


# chart 2 Total Price distribution

plt.figure(figsize=(9,5))
sns.histplot(df["TotalPrice"], bins=40, kde=True, color="steelblue")
plt.axvline(df["TotalPrice"].mean(), color="red", linestyle="--", 
            label=f"mean:{df['TotalPrice'].mean():.0f}")
plt.axhline(df["TotalPrice"].median(), color="green", linestyle="--",
            label=f"Median:{df["TotalPrice"].median():.0f}")
plt.legend()
plt.title('TotalPrice Distribution (Right-Skewed)')
plt.tight_layout()
plt.savefig('chart2_totalprice_dist.png')
plt.show()


# chart 3 Boxplot by product

plt.figure(figsize=(10,5))
sns.boxplot(x="Product", y ="TotalPrice", data= df, palette="Set2")
plt.title('TotalPrice by Product (Outliers Visible)')
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig('chart3_boxplot.png')
plt.show()


# chart 4 order status
status = df["OrderStatus"].value_counts()

plt.figure(figsize=(8,5))
status.plot(kind='bar', color="coral", edgecolor= "white",)
plt.title('Order Status Distribution')
plt.xlabel("status")
plt.ylabel("number of order")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig('chart4_order_status.png')
plt.show()


# chart 5 monthly revenue

monthly = df.groupby(df["Date"].dt.to_period("M"))["TotalPrice"].sum()

plt.figure(figsize=(13,5))
monthly.plot(kind='line', marker='o', color='coral', linewidth=2.5)
plt.title('Monthly Revenue Trend (2023–2025)')
plt.xlabel('Month')
plt.ylabel('Total Revenue ($)')
plt.xticks(rotation=60)
plt.tight_layout()
plt.savefig('chart5_monthly_trend.png')
plt.show()

print("\n===== KEY FINDINGS =====")
print(f"Total Orders   : {len(df)}")
print(f"Total Revenue  : ${df['TotalPrice'].sum():,.0f}")
print(f"Mean Order     : ${df['TotalPrice'].mean():.2f}")
print(f"Median Order   : ${df['TotalPrice'].median():.2f}  ← use this (right-skewed)")
print(f"Top Product    : {df.groupby('Product')['TotalPrice'].sum().idxmax()}")
print(f"Top Referral   : {df.groupby('ReferralSource')['TotalPrice'].sum().idxmax()}")
print(f"Cancelled %    : {(df['OrderStatus']=='Cancelled').mean()*100:.1f}%  ← needs action")
print(f"Coupon Usage   : {(df['CouponCode']!='No Coupon').mean()*100:.1f}%")




